# EVIDENCE — GOAL-000 Pi Runtime Bridge

> 本文件由实现 Agent 持续更新。
> 只记录真实执行结果，不允许预测或伪造。

## Status

`NOT STARTED`

---

## Baseline Audit

### Repository

- repo root:
- branch:
- package manager:
- runtime versions:
- monorepo:
- primary web app:
- primary host/server:
- test framework:

### Current Architecture

- UI entry:
- conversation UI:
- message send path:
- streaming path:
- session store:
- tool call path:
- artifact path:
- model selection:
- DSH host/runtime entry:
- Cordis/plugin usage:

### Shell / Runtime Boundary

#### Likely Shell

- TBD

#### Likely Runtime

- TBD

#### Coupled / Needs Bridge

- TBD

---

## Baseline

### Install

```bash
# TBD
```

Result:

```text
TBD
```

### Dev

```bash
# TBD
```

Result:

```text
TBD
```

### Build

```bash
# TBD
```

Result:

```text
TBD
```

### Typecheck

```bash
# TBD
```

Result:

```text
TBD
```

### Tests

```bash
# TBD
```

Result:

```text
TBD
```

### Pre-existing Failures

- TBD

---

## Implementation Evidence

### Workbench Contract

Files:

- TBD

Summary:

- TBD

Tests:

- TBD

---

### Pi Adapter

Files:

- TBD

Pi API actually used:

- TBD

Event mapping:

```text
Pi event -> Workbench event
TBD
```

Tests:

- TBD

---

### DSH Bridge

Files:

- TBD

Compatibility retained:

- TBD

Legacy runtime still active:

- TBD

---

## POC Evidence

### POC-01 Prompt

Status: `NOT RUN`

Evidence:

- TBD

---

### POC-02 Streaming

Status: `NOT RUN`

Observed delta count:

- TBD

Evidence:

- TBD

---

### POC-03 Tool Call

Status: `NOT RUN`

Tool:

- TBD

Lifecycle:

```text
TBD
```

Evidence:

- TBD

---

### POC-04 Session Resume

Status: `NOT RUN`

Mapping strategy:

- TBD

Evidence:

- TBD

---

### POC-05 Abort / Error

Status: `NOT RUN`

Evidence:

- TBD

---

## Regression

### Build

Status:

- TBD

### Typecheck

Status:

- TBD

### Unit Tests

Status:

- TBD

### Integration / E2E

Status:

- TBD

### Manual UI

Status:

- TBD

---

## Screenshots / Artifacts

- TBD

---

## Commits

- TBD

---

## Changed Files

- TBD

---

## Temporary Compatibility

- TBD

---

## Remaining Legacy DSH Dependencies

- TBD

---

## Known Issues

- TBD

---

## Final Acceptance

```text
P0-01 Baseline          [ ]
P0-02 Pi Prompt         [ ]
P0-03 Streaming         [ ]
P0-04 Tool Call         [ ]
P0-05 Session Resume    [ ]
P0-06 Abort/Error       [ ]
P0-07 Isolation         [ ]
P0-08 Regression        [ ]
```

---

## Final Status

`NOT DONE`
